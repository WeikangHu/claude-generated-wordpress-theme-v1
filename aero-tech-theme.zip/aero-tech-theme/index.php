<?php
/**
 * The main template file
 *
 * @package AeroTech
 */

get_header();
?>

<div class="content-area">
    <div class="container">
        <div class="archive-header">
            <h1 class="archive-title gradient-text">
                <?php
                if ( is_home() && ! is_front_page() ) {
                    single_post_title();
                } elseif ( is_archive() ) {
                    the_archive_title();
                } elseif ( is_search() ) {
                    printf( __( 'Search Results for: %s', 'aero-tech' ), get_search_query() );
                } else {
                    _e( 'Latest Articles', 'aero-tech' );
                }
                ?>
            </h1>
            
            <?php if ( is_archive() ) : ?>
                <div class="archive-description">
                    <?php the_archive_description(); ?>
                </div>
            <?php endif; ?>
        </div>
        
        <div class="posts-grid">
            <?php
            if ( have_posts() ) :
                while ( have_posts() ) :
                    the_post();
                    ?>
                    
                    <article id="post-<?php the_ID(); ?>" <?php post_class( 'post-card reveal' ); ?>>
                        
                        <?php if ( has_post_thumbnail() ) : ?>
                            <div class="post-thumbnail">
                                <a href="<?php the_permalink(); ?>">
                                    <?php the_post_thumbnail( 'aero-tech-card' ); ?>
                                </a>
                            </div>
                        <?php endif; ?>
                        
                        <div class="post-content">
                            
                            <div class="post-meta">
                                <span class="post-date">
                                    <?php echo get_the_date(); ?>
                                </span>
                                
                                <?php
                                $categories = get_the_category();
                                if ( ! empty( $categories ) ) :
                                ?>
                                    <span class="post-category">
                                        <a href="<?php echo esc_url( get_category_link( $categories[0]->term_id ) ); ?>">
                                            <?php echo esc_html( $categories[0]->name ); ?>
                                        </a>
                                    </span>
                                <?php endif; ?>
                            </div>
                            
                            <h2 class="post-title">
                                <a href="<?php the_permalink(); ?>">
                                    <?php the_title(); ?>
                                </a>
                            </h2>
                            
                            <div class="post-excerpt">
                                <?php the_excerpt(); ?>
                            </div>
                            
                            <a href="<?php the_permalink(); ?>" class="read-more">
                                <?php _e( 'Read More', 'aero-tech' ); ?>
                                <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
                                    <path d="M6 12l4-4-4-4" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                </svg>
                            </a>
                            
                        </div>
                    </article>
                    
                    <?php
                endwhile;
                
                // Pagination
                the_posts_pagination( array(
                    'mid_size'  => 2,
                    'prev_text' => __( '← Previous', 'aero-tech' ),
                    'next_text' => __( 'Next →', 'aero-tech' ),
                ));
                
            else :
                ?>
                <div class="no-posts">
                    <h2><?php _e( 'Nothing Found', 'aero-tech' ); ?></h2>
                    <p><?php _e( 'Sorry, no posts matched your criteria.', 'aero-tech' ); ?></p>
                </div>
                <?php
            endif;
            ?>
        </div>
    </div>
</div>

<style>
.archive-header {
    text-align: center;
    padding: 8rem 0 4rem;
}

.archive-title {
    font-size: clamp(2.5rem, 5vw, 4rem);
    margin-bottom: 1rem;
}

.archive-description {
    font-size: var(--font-size-lg);
    color: var(--color-text-secondary);
    max-width: 800px;
    margin: 0 auto;
}

.posts-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(350px, 1fr));
    gap: 2rem;
    padding-bottom: 4rem;
}

.post-card {
    background: var(--color-bg-secondary);
    border-radius: var(--radius-2xl);
    overflow: hidden;
    border: 1px solid rgba(255, 255, 255, 0.05);
    transition: all var(--transition-base);
}

.post-card:hover {
    transform: translateY(-8px);
    box-shadow: 0 24px 64px rgba(0, 0, 0, 0.4);
    border-color: rgba(0, 212, 255, 0.3);
}

.post-thumbnail {
    aspect-ratio: 16 / 9;
    overflow: hidden;
}

.post-thumbnail img {
    width: 100%;
    height: 100%;
    object-fit: cover;
    transition: transform var(--transition-slow);
}

.post-card:hover .post-thumbnail img {
    transform: scale(1.1);
}

.post-content {
    padding: 2rem;
}

.post-meta {
    display: flex;
    gap: 1rem;
    font-size: var(--font-size-xs);
    color: var(--color-text-tertiary);
    text-transform: uppercase;
    letter-spacing: 0.1em;
    margin-bottom: 1rem;
}

.post-category a {
    color: var(--color-accent-cyan);
}

.post-title {
    font-size: var(--font-size-xl);
    margin-bottom: 1rem;
}

.post-title a {
    color: var(--color-text-primary);
    transition: color var(--transition-fast);
}

.post-title a:hover {
    color: var(--color-accent-cyan);
}

.post-excerpt {
    color: var(--color-text-secondary);
    margin-bottom: 1.5rem;
    line-height: 1.6;
}

.read-more {
    display: inline-flex;
    align-items: center;
    gap: 0.5rem;
    font-size: var(--font-size-sm);
    font-weight: 600;
    color: var(--color-accent-cyan);
    transition: all var(--transition-fast);
}

.read-more:hover {
    gap: 0.75rem;
}

.no-posts {
    grid-column: 1 / -1;
    text-align: center;
    padding: 4rem 2rem;
}

.pagination {
    display: flex;
    justify-content: center;
    gap: 1rem;
    padding: 2rem 0;
    grid-column: 1 / -1;
}

.pagination a,
.pagination span {
    padding: 0.75rem 1.5rem;
    background: rgba(255, 255, 255, 0.05);
    border-radius: var(--radius-md);
    color: var(--color-text-secondary);
    transition: all var(--transition-fast);
}

.pagination a:hover,
.pagination .current {
    background: linear-gradient(135deg, var(--color-accent-cyan), var(--color-accent-blue));
    color: var(--color-bg-primary);
}

@media (max-width: 768px) {
    .posts-grid {
        grid-template-columns: 1fr;
    }
    
    .archive-header {
        padding: 6rem 0 2rem;
    }
}
</style>

<?php
get_footer();
