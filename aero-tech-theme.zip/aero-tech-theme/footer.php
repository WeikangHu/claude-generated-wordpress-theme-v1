    </main><!-- #main -->
    
    <!-- Footer - Apple-inspired minimal design with DJI tech elements -->
    <footer id="colophon" class="site-footer" role="contentinfo">
        
        <!-- Footer Widgets -->
        <?php if ( is_active_sidebar( 'footer-1' ) || is_active_sidebar( 'footer-2' ) || is_active_sidebar( 'footer-3' ) || is_active_sidebar( 'footer-4' ) ) : ?>
        <div class="footer-widgets">
            <div class="container">
                <div class="footer-widget-grid">
                    
                    <?php if ( is_active_sidebar( 'footer-1' ) ) : ?>
                    <div class="footer-widget-col">
                        <?php dynamic_sidebar( 'footer-1' ); ?>
                    </div>
                    <?php endif; ?>
                    
                    <?php if ( is_active_sidebar( 'footer-2' ) ) : ?>
                    <div class="footer-widget-col">
                        <?php dynamic_sidebar( 'footer-2' ); ?>
                    </div>
                    <?php endif; ?>
                    
                    <?php if ( is_active_sidebar( 'footer-3' ) ) : ?>
                    <div class="footer-widget-col">
                        <?php dynamic_sidebar( 'footer-3' ); ?>
                    </div>
                    <?php endif; ?>
                    
                    <?php if ( is_active_sidebar( 'footer-4' ) ) : ?>
                    <div class="footer-widget-col">
                        <?php dynamic_sidebar( 'footer-4' ); ?>
                    </div>
                    <?php endif; ?>
                    
                </div>
            </div>
        </div>
        <?php endif; ?>
        
        <!-- Footer Navigation -->
        <div class="footer-navigation">
            <div class="container">
                <?php
                if ( has_nav_menu( 'footer' ) ) {
                    wp_nav_menu( array(
                        'theme_location' => 'footer',
                        'menu_id'        => 'footer-menu',
                        'menu_class'     => 'footer-menu',
                        'container'      => false,
                        'depth'          => 1,
                    ));
                }
                ?>
            </div>
        </div>
        
        <!-- Footer Bottom -->
        <div class="footer-bottom">
            <div class="container">
                <div class="footer-bottom-content">
                    
                    <!-- Copyright -->
                    <div class="copyright">
                        <p>
                            &copy; <?php echo date( 'Y' ); ?> 
                            <a href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php bloginfo( 'name' ); ?></a>
                            <span class="separator">|</span>
                            <?php esc_html_e( 'All rights reserved', 'aero-tech' ); ?>
                        </p>
                    </div>
                    
                    <!-- Social Links -->
                    <div class="social-links">
                        <?php
                        // You can add social links via Customizer
                        $social_links = array(
                            'twitter'   => get_theme_mod( 'aero_tech_twitter_url' ),
                            'facebook'  => get_theme_mod( 'aero_tech_facebook_url' ),
                            'instagram' => get_theme_mod( 'aero_tech_instagram_url' ),
                            'youtube'   => get_theme_mod( 'aero_tech_youtube_url' ),
                            'linkedin'  => get_theme_mod( 'aero_tech_linkedin_url' ),
                        );
                        
                        foreach ( $social_links as $platform => $url ) :
                            if ( $url ) :
                        ?>
                            <a href="<?php echo esc_url( $url ); ?>" class="social-link social-<?php echo esc_attr( $platform ); ?>" target="_blank" rel="noopener noreferrer" aria-label="<?php echo esc_attr( ucfirst( $platform ) ); ?>">
                                <?php echo aero_tech_get_social_icon( $platform ); ?>
                            </a>
                        <?php
                            endif;
                        endforeach;
                        ?>
                    </div>
                    
                </div>
            </div>
        </div>
        
        <!-- Tech Pattern Background -->
        <div class="footer-pattern" aria-hidden="true">
            <svg width="100%" height="100%" xmlns="http://www.w3.org/2000/svg">
                <defs>
                    <pattern id="tech-grid" x="0" y="0" width="50" height="50" patternUnits="userSpaceOnUse">
                        <circle cx="25" cy="25" r="1" fill="rgba(0, 212, 255, 0.1)"/>
                    </pattern>
                </defs>
                <rect width="100%" height="100%" fill="url(#tech-grid)"/>
            </svg>
        </div>
        
    </footer><!-- #colophon -->
    
    <!-- Back to Top Button -->
    <button class="back-to-top" aria-label="<?php esc_attr_e( 'Back to Top', 'aero-tech' ); ?>" style="display: none;">
        <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
            <path d="M12 19V5M5 12l7-7 7 7" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
        </svg>
    </button>
    
</div><!-- #page -->

<?php wp_footer(); ?>

</body>
</html>

<?php
/**
 * Helper function to get social media icons
 */
function aero_tech_get_social_icon( $platform ) {
    $icons = array(
        'twitter' => '<svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor"><path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z"/></svg>',
        'facebook' => '<svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor"><path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/></svg>',
        'instagram' => '<svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor"><path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z"/></svg>',
        'youtube' => '<svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor"><path d="M23.498 6.186a3.016 3.016 0 0 0-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 0 0 .502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 0 0 2.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.015 3.015 0 0 0 2.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814zM9.545 15.568V8.432L15.818 12l-6.273 3.568z"/></svg>',
        'linkedin' => '<svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor"><path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433c-1.144 0-2.063-.926-2.063-2.065 0-1.138.92-2.063 2.063-2.063 1.14 0 2.064.925 2.064 2.063 0 1.139-.925 2.065-2.064 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z"/></svg>',
    );
    
    return isset( $icons[$platform] ) ? $icons[$platform] : '';
}
