<?php
/**
 * Aero Tech Theme Customizer
 *
 * @package AeroTech
 */

/**
 * Add postMessage support for site title and description
 */
function aero_tech_customize_register( $wp_customize ) {
    
    $wp_customize->get_setting( 'blogname' )->transport = 'postMessage';
    $wp_customize->get_setting( 'blogdescription' )->transport = 'postMessage';
    
    if ( isset( $wp_customize->selective_refresh ) ) {
        $wp_customize->selective_refresh->add_partial( 'blogname', array(
            'selector'        => '.site-title',
            'render_callback' => 'aero_tech_customize_partial_blogname',
        ));
        
        $wp_customize->selective_refresh->add_partial( 'blogdescription', array(
            'selector'        => '.site-description',
            'render_callback' => 'aero_tech_customize_partial_blogdescription',
        ));
    }
    
    // ========================================
    // Social Media Section
    // ========================================
    
    $wp_customize->add_section( 'aero_tech_social_media', array(
        'title'    => __( 'Social Media Links', 'aero-tech' ),
        'priority' => 130,
    ));
    
    // Twitter
    $wp_customize->add_setting( 'aero_tech_twitter_url', array(
        'default'           => '',
        'sanitize_callback' => 'esc_url_raw',
    ));
    
    $wp_customize->add_control( 'aero_tech_twitter_url', array(
        'label'   => __( 'Twitter URL', 'aero-tech' ),
        'section' => 'aero_tech_social_media',
        'type'    => 'url',
    ));
    
    // Facebook
    $wp_customize->add_setting( 'aero_tech_facebook_url', array(
        'default'           => '',
        'sanitize_callback' => 'esc_url_raw',
    ));
    
    $wp_customize->add_control( 'aero_tech_facebook_url', array(
        'label'   => __( 'Facebook URL', 'aero-tech' ),
        'section' => 'aero_tech_social_media',
        'type'    => 'url',
    ));
    
    // Instagram
    $wp_customize->add_setting( 'aero_tech_instagram_url', array(
        'default'           => '',
        'sanitize_callback' => 'esc_url_raw',
    ));
    
    $wp_customize->add_control( 'aero_tech_instagram_url', array(
        'label'   => __( 'Instagram URL', 'aero-tech' ),
        'section' => 'aero_tech_social_media',
        'type'    => 'url',
    ));
    
    // YouTube
    $wp_customize->add_setting( 'aero_tech_youtube_url', array(
        'default'           => '',
        'sanitize_callback' => 'esc_url_raw',
    ));
    
    $wp_customize->add_control( 'aero_tech_youtube_url', array(
        'label'   => __( 'YouTube URL', 'aero-tech' ),
        'section' => 'aero_tech_social_media',
        'type'    => 'url',
    ));
    
    // LinkedIn
    $wp_customize->add_setting( 'aero_tech_linkedin_url', array(
        'default'           => '',
        'sanitize_callback' => 'esc_url_raw',
    ));
    
    $wp_customize->add_control( 'aero_tech_linkedin_url', array(
        'label'   => __( 'LinkedIn URL', 'aero-tech' ),
        'section' => 'aero_tech_social_media',
        'type'    => 'url',
    ));
    
    // ========================================
    // Theme Colors Section
    // ========================================
    
    $wp_customize->add_section( 'aero_tech_colors', array(
        'title'    => __( 'Theme Colors', 'aero-tech' ),
        'priority' => 40,
    ));
    
    // Accent Color
    $wp_customize->add_setting( 'aero_tech_accent_color', array(
        'default'           => '#00d4ff',
        'sanitize_callback' => 'sanitize_hex_color',
    ));
    
    $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'aero_tech_accent_color', array(
        'label'   => __( 'Accent Color', 'aero-tech' ),
        'section' => 'aero_tech_colors',
    )));
    
    // Secondary Accent Color
    $wp_customize->add_setting( 'aero_tech_secondary_accent', array(
        'default'           => '#0071e3',
        'sanitize_callback' => 'sanitize_hex_color',
    ));
    
    $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'aero_tech_secondary_accent', array(
        'label'   => __( 'Secondary Accent Color', 'aero-tech' ),
        'section' => 'aero_tech_colors',
    )));
    
    // ========================================
    // Header Settings
    // ========================================
    
    $wp_customize->add_section( 'aero_tech_header_settings', array(
        'title'    => __( 'Header Settings', 'aero-tech' ),
        'priority' => 50,
    ));
    
    // Header Transparency
    $wp_customize->add_setting( 'aero_tech_header_transparent', array(
        'default'           => true,
        'sanitize_callback' => 'aero_tech_sanitize_checkbox',
    ));
    
    $wp_customize->add_control( 'aero_tech_header_transparent', array(
        'label'   => __( 'Transparent Header on Homepage', 'aero-tech' ),
        'section' => 'aero_tech_header_settings',
        'type'    => 'checkbox',
    ));
    
    // Show Search Icon
    $wp_customize->add_setting( 'aero_tech_show_search', array(
        'default'           => true,
        'sanitize_callback' => 'aero_tech_sanitize_checkbox',
    ));
    
    $wp_customize->add_control( 'aero_tech_show_search', array(
        'label'   => __( 'Show Search Icon', 'aero-tech' ),
        'section' => 'aero_tech_header_settings',
        'type'    => 'checkbox',
    ));
    
    // ========================================
    // Footer Settings
    // ========================================
    
    $wp_customize->add_section( 'aero_tech_footer_settings', array(
        'title'    => __( 'Footer Settings', 'aero-tech' ),
        'priority' => 120,
    ));
    
    // Footer Copyright Text
    $wp_customize->add_setting( 'aero_tech_footer_copyright', array(
        'default'           => '',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    
    $wp_customize->add_control( 'aero_tech_footer_copyright', array(
        'label'       => __( 'Custom Copyright Text', 'aero-tech' ),
        'description' => __( 'Leave empty to use default copyright text', 'aero-tech' ),
        'section'     => 'aero_tech_footer_settings',
        'type'        => 'text',
    ));
}
add_action( 'customize_register', 'aero_tech_customize_register' );

/**
 * Render the site title for the selective refresh partial.
 */
function aero_tech_customize_partial_blogname() {
    bloginfo( 'name' );
}

/**
 * Render the site tagline for the selective refresh partial.
 */
function aero_tech_customize_partial_blogdescription() {
    bloginfo( 'description' );
}

/**
 * Sanitize checkbox
 */
function aero_tech_sanitize_checkbox( $checked ) {
    return ( ( isset( $checked ) && true == $checked ) ? true : false );
}

/**
 * Binds JS handlers to make Theme Customizer preview reload changes asynchronously.
 */
function aero_tech_customize_preview_js() {
    wp_enqueue_script( 'aero-tech-customizer', get_template_directory_uri() . '/assets/js/customizer.js', array( 'customize-preview' ), AERO_TECH_VERSION, true );
}
add_action( 'customize_preview_init', 'aero_tech_customize_preview_js' );

/**
 * Output custom CSS to head
 */
function aero_tech_custom_css() {
    $accent_color = get_theme_mod( 'aero_tech_accent_color', '#00d4ff' );
    $secondary_accent = get_theme_mod( 'aero_tech_secondary_accent', '#0071e3' );
    
    ?>
    <style type="text/css">
        :root {
            --color-accent-cyan: <?php echo esc_attr( $accent_color ); ?>;
            --color-accent-blue: <?php echo esc_attr( $secondary_accent ); ?>;
        }
    </style>
    <?php
}
add_action( 'wp_head', 'aero_tech_custom_css' );
