/**
 * Aero Tech - Advanced Animations
 * DJI-inspired product showcase animations
 */

(function() {
    'use strict';
    
    // ========================================
    // Parallax Effect for Hero Section
    // ========================================
    
    function initParallax() {
        const heroSection = document.querySelector('.hero-section');
        const heroBackground = document.querySelector('.hero-background');
        
        if (!heroSection || !heroBackground) return;
        
        window.addEventListener('scroll', function() {
            const scrolled = window.pageYOffset;
            const rate = scrolled * 0.5;
            
            heroBackground.style.transform = `translateY(${rate}px)`;
        }, { passive: true });
    }
    
    // ========================================
    // 3D Product Card Tilt Effect
    // ========================================
    
    function init3DTilt() {
        const cards = document.querySelectorAll('.product-card');
        
        cards.forEach(card => {
            card.addEventListener('mousemove', function(e) {
                const rect = this.getBoundingClientRect();
                const x = e.clientX - rect.left;
                const y = e.clientY - rect.top;
                
                const centerX = rect.width / 2;
                const centerY = rect.height / 2;
                
                const rotateX = (y - centerY) / 10;
                const rotateY = (centerX - x) / 10;
                
                this.style.transform = `perspective(1000px) rotateX(${rotateX}deg) rotateY(${rotateY}deg) translateY(-8px)`;
            });
            
            card.addEventListener('mouseleave', function() {
                this.style.transform = 'perspective(1000px) rotateX(0) rotateY(0) translateY(0)';
            });
        });
    }
    
    // ========================================
    // Magnetic Button Effect
    // ========================================
    
    function initMagneticButtons() {
        const buttons = document.querySelectorAll('.btn, .product-button');
        
        buttons.forEach(button => {
            button.addEventListener('mousemove', function(e) {
                const rect = this.getBoundingClientRect();
                const x = e.clientX - rect.left - rect.width / 2;
                const y = e.clientY - rect.top - rect.height / 2;
                
                this.style.transform = `translate(${x * 0.2}px, ${y * 0.2}px)`;
            });
            
            button.addEventListener('mouseleave', function() {
                this.style.transform = 'translate(0, 0)';
            });
        });
    }
    
    // ========================================
    // Stagger Animation for Product Grid
    // ========================================
    
    function initStaggerAnimation() {
        const products = document.querySelectorAll('.product-card');
        
        if ('IntersectionObserver' in window) {
            const observer = new IntersectionObserver((entries) => {
                entries.forEach((entry, index) => {
                    if (entry.isIntersecting) {
                        setTimeout(() => {
                            entry.target.style.opacity = '1';
                            entry.target.style.transform = 'translateY(0)';
                        }, index * 100);
                        
                        observer.unobserve(entry.target);
                    }
                });
            }, {
                threshold: 0.1
            });
            
            products.forEach(product => {
                product.style.opacity = '0';
                product.style.transform = 'translateY(50px)';
                product.style.transition = 'all 0.6s cubic-bezier(0.16, 1, 0.3, 1)';
                observer.observe(product);
            });
        }
    }
    
    // ========================================
    // Cursor Trail Effect (Optional)
    // ========================================
    
    function initCursorTrail() {
        // Only on desktop devices
        if (window.innerWidth < 1024) return;
        
        const cursor = document.createElement('div');
        cursor.className = 'custom-cursor';
        cursor.style.cssText = `
            position: fixed;
            width: 20px;
            height: 20px;
            border-radius: 50%;
            background: rgba(0, 212, 255, 0.3);
            pointer-events: none;
            z-index: 9999;
            transition: transform 0.15s ease-out, opacity 0.15s ease-out;
            mix-blend-mode: difference;
            display: none;
        `;
        document.body.appendChild(cursor);
        
        let mouseX = 0;
        let mouseY = 0;
        let cursorX = 0;
        let cursorY = 0;
        
        document.addEventListener('mousemove', function(e) {
            mouseX = e.clientX;
            mouseY = e.clientY;
            cursor.style.display = 'block';
        });
        
        function animateCursor() {
            cursorX += (mouseX - cursorX) * 0.2;
            cursorY += (mouseY - cursorY) * 0.2;
            
            cursor.style.transform = `translate(${cursorX - 10}px, ${cursorY - 10}px)`;
            
            requestAnimationFrame(animateCursor);
        }
        
        animateCursor();
        
        // Enlarge cursor on hover over interactive elements
        const interactiveElements = document.querySelectorAll('a, button, .product-card');
        
        interactiveElements.forEach(el => {
            el.addEventListener('mouseenter', function() {
                cursor.style.transform = `translate(${cursorX - 15}px, ${cursorY - 15}px) scale(1.5)`;
            });
            
            el.addEventListener('mouseleave', function() {
                cursor.style.transform = `translate(${cursorX - 10}px, ${cursorY - 10}px) scale(1)`;
            });
        });
    }
    
    // ========================================
    // Number Counter Animation
    // ========================================
    
    function initCounters() {
        const counters = document.querySelectorAll('[data-counter]');
        
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    const target = parseInt(entry.target.dataset.counter);
                    const duration = 2000;
                    const increment = target / (duration / 16);
                    let current = 0;
                    
                    const timer = setInterval(() => {
                        current += increment;
                        
                        if (current >= target) {
                            entry.target.textContent = target.toLocaleString();
                            clearInterval(timer);
                        } else {
                            entry.target.textContent = Math.floor(current).toLocaleString();
                        }
                    }, 16);
                    
                    observer.unobserve(entry.target);
                }
            });
        }, {
            threshold: 0.5
        });
        
        counters.forEach(counter => {
            observer.observe(counter);
        });
    }
    
    // ========================================
    // Smooth Scroll with Offset
    // ========================================
    
    function initSmoothScroll() {
        // Add smooth scrolling behavior
        document.documentElement.style.scrollBehavior = 'smooth';
        
        // Handle anchor links with header offset
        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', function(e) {
                const href = this.getAttribute('href');
                
                if (href !== '#' && href !== '#0') {
                    const target = document.querySelector(href);
                    
                    if (target) {
                        e.preventDefault();
                        
                        const headerHeight = document.querySelector('.site-header').offsetHeight;
                        const targetPosition = target.getBoundingClientRect().top + window.pageYOffset - headerHeight - 20;
                        
                        window.scrollTo({
                            top: targetPosition,
                            behavior: 'smooth'
                        });
                    }
                }
            });
        });
    }
    
    // ========================================
    // Image Reveal Animation
    // ========================================
    
    function initImageReveal() {
        const images = document.querySelectorAll('.product-image img, .hero-image img');
        
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.style.opacity = '1';
                    entry.target.style.transform = 'scale(1)';
                    observer.unobserve(entry.target);
                }
            });
        }, {
            threshold: 0.1
        });
        
        images.forEach(img => {
            img.style.opacity = '0';
            img.style.transform = 'scale(0.95)';
            img.style.transition = 'all 1s cubic-bezier(0.16, 1, 0.3, 1)';
            observer.observe(img);
        });
    }
    
    // ========================================
    // Text Reveal Animation
    // ========================================
    
    function initTextReveal() {
        const textElements = document.querySelectorAll('.hero-title, .hero-subtitle, .section-title');
        
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.classList.add('revealed');
                    observer.unobserve(entry.target);
                }
            });
        }, {
            threshold: 0.5
        });
        
        textElements.forEach(el => {
            el.style.opacity = '0';
            el.style.transform = 'translateY(30px)';
            observer.observe(el);
        });
        
        // Add CSS for revealed state
        const style = document.createElement('style');
        style.textContent = `
            .revealed {
                animation: fadeInUp 0.8s cubic-bezier(0.16, 1, 0.3, 1) forwards;
            }
        `;
        document.head.appendChild(style);
    }
    
    // ========================================
    // Loading Animation
    // ========================================
    
    function initLoadingAnimation() {
        window.addEventListener('load', function() {
            document.body.classList.add('loaded');
            
            // Add loading animation styles
            const style = document.createElement('style');
            style.textContent = `
                body:not(.loaded) {
                    overflow: hidden;
                }
                
                body:not(.loaded)::before {
                    content: '';
                    position: fixed;
                    top: 0;
                    left: 0;
                    right: 0;
                    bottom: 0;
                    background: #000;
                    z-index: 99999;
                    transition: opacity 0.5s ease-out;
                }
                
                body.loaded::before {
                    opacity: 0;
                    pointer-events: none;
                }
            `;
            document.head.appendChild(style);
        });
    }
    
    // ========================================
    // Initialize All Animations
    // ========================================
    
    function init() {
        initParallax();
        init3DTilt();
        initMagneticButtons();
        initStaggerAnimation();
        initCounters();
        initSmoothScroll();
        initImageReveal();
        initTextReveal();
        initLoadingAnimation();
        
        // Optional: Enable cursor trail on desktop
        // initCursorTrail();
    }
    
    // Run on DOM ready
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }
    
})();
