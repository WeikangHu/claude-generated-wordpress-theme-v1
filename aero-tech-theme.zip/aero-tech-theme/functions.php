<?php
/**
 * Aero Tech Theme Functions
 * 
 * Combines Apple's refined minimalism with DJI's technological innovation
 * 
 * @package AeroTech
 * @version 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

// Theme Constants
define( 'AERO_TECH_VERSION', '1.0.0' );
define( 'AERO_TECH_PATH', get_template_directory() );
define( 'AERO_TECH_URI', get_template_directory_uri() );

/**
 * Theme Setup
 */
function aero_tech_setup() {
    // Add theme support
    add_theme_support( 'title-tag' );
    add_theme_support( 'post-thumbnails' );
    add_theme_support( 'responsive-embeds' );
    add_theme_support( 'html5', array(
        'search-form',
        'comment-form',
        'comment-list',
        'gallery',
        'caption',
        'style',
        'script'
    ));
    
    // Custom logo support
    add_theme_support( 'custom-logo', array(
        'height'      => 60,
        'width'       => 200,
        'flex-height' => true,
        'flex-width'  => true,
    ));
    
    // WooCommerce support
    add_theme_support( 'woocommerce' );
    add_theme_support( 'wc-product-gallery-zoom' );
    add_theme_support( 'wc-product-gallery-lightbox' );
    add_theme_support( 'wc-product-gallery-slider' );
    
    // Custom image sizes
    add_image_size( 'aero-tech-hero', 1920, 1080, true );
    add_image_size( 'aero-tech-product', 800, 800, true );
    add_image_size( 'aero-tech-card', 600, 400, true );
    
    // Register Navigation Menus
    register_nav_menus( array(
        'primary'   => __( 'Primary Menu', 'aero-tech' ),
        'footer'    => __( 'Footer Menu', 'aero-tech' ),
        'mobile'    => __( 'Mobile Menu', 'aero-tech' ),
    ));
    
    // Content width
    if ( ! isset( $content_width ) ) {
        $content_width = 1440;
    }
}
add_action( 'after_setup_theme', 'aero_tech_setup' );

/**
 * Enqueue Scripts and Styles
 */
function aero_tech_enqueue_scripts() {
    // Main stylesheet
    wp_enqueue_style( 'aero-tech-style', get_stylesheet_uri(), array(), AERO_TECH_VERSION );
    
    // Custom CSS
    wp_enqueue_style( 'aero-tech-custom', AERO_TECH_URI . '/assets/css/custom.css', array(), AERO_TECH_VERSION );
    
    // Google Fonts - Using Orbitron for display (tech/futuristic) and Inter for body
    wp_enqueue_style( 'aero-tech-fonts', 'https://fonts.googleapis.com/css2?family=Orbitron:wght@400;500;600;700;800;900&family=Inter:wght@300;400;500;600;700&display=swap', array(), null );
    
    // Main JavaScript
    wp_enqueue_script( 'aero-tech-main', AERO_TECH_URI . '/assets/js/main.js', array(), AERO_TECH_VERSION, true );
    
    // Smooth scroll
    wp_enqueue_script( 'aero-tech-smooth-scroll', AERO_TECH_URI . '/assets/js/smooth-scroll.js', array(), AERO_TECH_VERSION, true );
    
    // Product showcase animations
    wp_enqueue_script( 'aero-tech-animations', AERO_TECH_URI . '/assets/js/animations.js', array(), AERO_TECH_VERSION, true );
    
    // Localize script for AJAX
    wp_localize_script( 'aero-tech-main', 'aeroTech', array(
        'ajaxurl' => admin_url( 'admin-ajax.php' ),
        'nonce'   => wp_create_nonce( 'aero-tech-nonce' ),
    ));
    
    // Comment reply
    if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
        wp_enqueue_script( 'comment-reply' );
    }
}
add_action( 'wp_enqueue_scripts', 'aero_tech_enqueue_scripts' );

/**
 * Register Widget Areas
 */
function aero_tech_widgets_init() {
    register_sidebar( array(
        'name'          => __( 'Footer Widget Area 1', 'aero-tech' ),
        'id'            => 'footer-1',
        'description'   => __( 'First footer widget area', 'aero-tech' ),
        'before_widget' => '<div id="%1$s" class="footer-widget %2$s">',
        'after_widget'  => '</div>',
        'before_title'  => '<h3 class="widget-title">',
        'after_title'   => '</h3>',
    ));
    
    register_sidebar( array(
        'name'          => __( 'Footer Widget Area 2', 'aero-tech' ),
        'id'            => 'footer-2',
        'description'   => __( 'Second footer widget area', 'aero-tech' ),
        'before_widget' => '<div id="%1$s" class="footer-widget %2$s">',
        'after_widget'  => '</div>',
        'before_title'  => '<h3 class="widget-title">',
        'after_title'   => '</h3>',
    ));
    
    register_sidebar( array(
        'name'          => __( 'Footer Widget Area 3', 'aero-tech' ),
        'id'            => 'footer-3',
        'description'   => __( 'Third footer widget area', 'aero-tech' ),
        'before_widget' => '<div id="%1$s" class="footer-widget %2$s">',
        'after_widget'  => '</div>',
        'before_title'  => '<h3 class="widget-title">',
        'after_title'   => '</h3>',
    ));
    
    register_sidebar( array(
        'name'          => __( 'Footer Widget Area 4', 'aero-tech' ),
        'id'            => 'footer-4',
        'description'   => __( 'Fourth footer widget area', 'aero-tech' ),
        'before_widget' => '<div id="%1$s" class="footer-widget %2$s">',
        'after_widget'  => '</div>',
        'before_title'  => '<h3 class="widget-title">',
        'after_title'   => '</h3>',
    ));
}
add_action( 'widgets_init', 'aero_tech_widgets_init' );

/**
 * Custom Excerpt Length
 */
function aero_tech_excerpt_length( $length ) {
    return 30;
}
add_filter( 'excerpt_length', 'aero_tech_excerpt_length' );

/**
 * Custom Excerpt More
 */
function aero_tech_excerpt_more( $more ) {
    return '...';
}
add_filter( 'excerpt_more', 'aero_tech_excerpt_more' );

/**
 * Add Body Classes
 */
function aero_tech_body_classes( $classes ) {
    // Add class if sidebar is active
    if ( is_active_sidebar( 'sidebar-1' ) ) {
        $classes[] = 'has-sidebar';
    }
    
    // Add class for different page types
    if ( is_singular() ) {
        $classes[] = 'singular-page';
    }
    
    if ( is_front_page() ) {
        $classes[] = 'front-page-hero';
    }
    
    return $classes;
}
add_filter( 'body_class', 'aero_tech_body_classes' );

/**
 * WooCommerce Customizations
 */
if ( class_exists( 'WooCommerce' ) ) {
    // Remove default WooCommerce styles
    add_filter( 'woocommerce_enqueue_styles', '__return_empty_array' );
    
    // Customize product columns
    function aero_tech_loop_columns() {
        return 3; // 3 products per row
    }
    add_filter( 'loop_shop_columns', 'aero_tech_loop_columns' );
    
    // Products per page
    function aero_tech_products_per_page() {
        return 12;
    }
    add_filter( 'loop_shop_per_page', 'aero_tech_products_per_page' );
    
    // Remove product thumbnails from cart
    add_filter( 'woocommerce_cart_item_thumbnail', '__return_false' );
    
    // Customize Add to Cart button text
    function aero_tech_custom_cart_button_text() {
        return __( 'Add to Bag', 'aero-tech' );
    }
    add_filter( 'woocommerce_product_single_add_to_cart_text', 'aero_tech_custom_cart_button_text' );
    add_filter( 'woocommerce_product_add_to_cart_text', 'aero_tech_custom_cart_button_text' );
}

/**
 * Include Additional Files
 */
require_once AERO_TECH_PATH . '/inc/customizer.php';
require_once AERO_TECH_PATH . '/inc/template-functions.php';
require_once AERO_TECH_PATH . '/inc/template-tags.php';

/**
 * Custom Template Tags
 */
if ( ! function_exists( 'aero_tech_posted_on' ) ) {
    function aero_tech_posted_on() {
        $time_string = '<time class="entry-date published updated" datetime="%1$s">%2$s</time>';
        
        $time_string = sprintf( $time_string,
            esc_attr( get_the_date( 'c' ) ),
            esc_html( get_the_date() )
        );
        
        echo '<span class="posted-on">' . $time_string . '</span>';
    }
}

if ( ! function_exists( 'aero_tech_posted_by' ) ) {
    function aero_tech_posted_by() {
        echo '<span class="byline">by <a href="' . esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ) . '">' . esc_html( get_the_author() ) . '</a></span>';
    }
}

/**
 * Comments Template
 */
if ( ! function_exists( 'aero_tech_comment' ) ) {
    function aero_tech_comment( $comment, $args, $depth ) {
        $tag = ( 'div' === $args['style' ] ) ? 'div' : 'li';
        ?>
        <<?php echo $tag; ?> id="comment-<?php comment_ID(); ?>" <?php comment_class( empty( $args['has_children'] ) ? '' : 'parent' ); ?>>
            <article id="div-comment-<?php comment_ID(); ?>" class="comment-body">
                <div class="comment-author vcard">
                    <?php echo get_avatar( $comment, $args['avatar_size'] ); ?>
                    <?php printf( '<b class="fn">%s</b>', get_comment_author_link() ); ?>
                </div>
                
                <div class="comment-metadata">
                    <a href="<?php echo esc_url( get_comment_link( $comment, $args ) ); ?>">
                        <time datetime="<?php comment_time( 'c' ); ?>">
                            <?php printf( '%1$s at %2$s', get_comment_date(), get_comment_time() ); ?>
                        </time>
                    </a>
                </div>
                
                <div class="comment-content">
                    <?php comment_text(); ?>
                </div>
                
                <?php
                comment_reply_link( array_merge( $args, array(
                    'depth'      => $depth,
                    'max_depth'  => $args['max_depth'],
                    'reply_text' => 'Reply',
                )));
                ?>
            </article>
        <?php
    }
}
