<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo( 'charset' ); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=5.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

<div id="page" class="site">
    
    <!-- Navigation - Apple-inspired with DJI tech elements -->
    <header id="masthead" class="site-header" role="banner">
        <nav class="main-navigation" role="navigation" aria-label="<?php esc_attr_e( 'Main Navigation', 'aero-tech' ); ?>">
            <div class="nav-container">
                
                <!-- Logo -->
                <div class="site-branding">
                    <?php if ( has_custom_logo() ) : ?>
                        <div class="site-logo">
                            <?php the_custom_logo(); ?>
                        </div>
                    <?php else : ?>
                        <a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="site-title" rel="home">
                            <?php bloginfo( 'name' ); ?>
                        </a>
                    <?php endif; ?>
                </div>
                
                <!-- Primary Menu -->
                <div class="nav-menu-wrapper">
                    <?php
                    wp_nav_menu( array(
                        'theme_location' => 'primary',
                        'menu_id'        => 'primary-menu',
                        'menu_class'     => 'nav-menu',
                        'container'      => false,
                        'fallback_cb'    => false,
                    ));
                    ?>
                </div>
                
                <!-- Right Side Actions -->
                <div class="nav-actions">
                    
                    <!-- Search Toggle -->
                    <button class="search-toggle" aria-label="<?php esc_attr_e( 'Toggle Search', 'aero-tech' ); ?>" aria-expanded="false">
                        <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M9 17A8 8 0 1 0 9 1a8 8 0 0 0 0 16zM19 19l-4.35-4.35" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                        </svg>
                    </button>
                    
                    <?php if ( class_exists( 'WooCommerce' ) ) : ?>
                        <!-- Cart Icon -->
                        <a href="<?php echo esc_url( wc_get_cart_url() ); ?>" class="cart-toggle" aria-label="<?php esc_attr_e( 'Shopping Cart', 'aero-tech' ); ?>">
                            <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M1 1h3l.58 2.91M5.58 3.91l1.42 7.09h9.45L18 5H6.16m-.58-1.09L4.42 13h11.16M7 18a1 1 0 1 0 0-2 1 1 0 0 0 0 2zm9 0a1 1 0 1 0 0-2 1 1 0 0 0 0 2z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                            </svg>
                            <?php
                            $cart_count = WC()->cart->get_cart_contents_count();
                            if ( $cart_count > 0 ) :
                            ?>
                                <span class="cart-count"><?php echo esc_html( $cart_count ); ?></span>
                            <?php endif; ?>
                        </a>
                    <?php endif; ?>
                    
                    <!-- Mobile Menu Toggle -->
                    <button class="mobile-menu-toggle" aria-label="<?php esc_attr_e( 'Toggle Menu', 'aero-tech' ); ?>" aria-expanded="false">
                        <span class="menu-icon">
                            <span></span>
                            <span></span>
                            <span></span>
                        </span>
                    </button>
                    
                </div>
            </div>
        </nav>
        
        <!-- Search Overlay -->
        <div class="search-overlay" id="search-overlay">
            <div class="search-overlay-content">
                <form role="search" method="get" class="search-form" action="<?php echo esc_url( home_url( '/' ) ); ?>">
                    <input type="search" class="search-field" placeholder="<?php esc_attr_e( 'Search...', 'aero-tech' ); ?>" value="<?php echo get_search_query(); ?>" name="s" />
                    <button type="submit" class="search-submit">
                        <svg width="24" height="24" viewBox="0 0 20 20" fill="none">
                            <path d="M9 17A8 8 0 1 0 9 1a8 8 0 0 0 0 16zM19 19l-4.35-4.35" stroke="currentColor" stroke-width="2"/>
                        </svg>
                    </button>
                </form>
                <button class="search-close" aria-label="<?php esc_attr_e( 'Close Search', 'aero-tech' ); ?>">
                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
                        <path d="M18 6L6 18M6 6l12 12" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
                    </svg>
                </button>
            </div>
        </div>
        
        <!-- Mobile Menu -->
        <div class="mobile-menu" id="mobile-menu">
            <div class="mobile-menu-content">
                <?php
                wp_nav_menu( array(
                    'theme_location' => 'mobile',
                    'menu_id'        => 'mobile-navigation',
                    'menu_class'     => 'mobile-nav-menu',
                    'container'      => false,
                    'fallback_cb'    => 'wp_page_menu',
                ));
                ?>
            </div>
        </div>
        
    </header>
    
    <!-- Progress Bar for Scroll -->
    <div class="scroll-progress">
        <div class="scroll-progress-bar"></div>
    </div>
    
    <main id="main" class="site-main">
